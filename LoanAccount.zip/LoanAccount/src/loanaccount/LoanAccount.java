/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package loanaccount;

/**
 *
 * @author Ethan
 */
public class LoanAccount {
    //instance variables
    private static double annualInterestRate;
    private double principal;
    
    //object constructor
    LoanAccount(double principal){
        this.principal = principal;
    }
    
    //method to set the annual interest rate
    public static void setAnnualInterestRate(double newAnnualInterestRate){
        annualInterestRate = newAnnualInterestRate;
    }
    
    //method to calculate monthly payment
    public double calculateMonthlyPayment(int numberOfPayments){
         double monthlyInterest = annualInterestRate/12;
         double monthlyPayment = principal*(monthlyInterest/(1-Math.pow(1+monthlyInterest,-numberOfPayments)));
         return monthlyPayment;
    }
    public static void main(String[] args) {
        //creating loan1 and loan2 objects
        LoanAccount loan1 = new LoanAccount(5000.00);
        LoanAccount loan2 = new LoanAccount(31000.00);
        
        //setting annualInterestRate to 1%
        setAnnualInterestRate(.01); 
        
        //formatting output
        System.out.print("Monthly payments for loan1 of $5000.00 and loan2 $31000.00 for 3, 5 and 6 year loans at 1% interest.\n");
        System.out.printf("Loan\t3 years\t5 years\t6 years\nLoan1\t%.2f\t%.2f\t%.2f\nLoan2\t%.2f\t%.2f\t%.2f\n\n", 
                loan1.calculateMonthlyPayment(36), loan1.calculateMonthlyPayment(60), loan1.calculateMonthlyPayment(72),
                loan2.calculateMonthlyPayment(36), loan2.calculateMonthlyPayment(60), loan2.calculateMonthlyPayment(72));
        
        //setting annualInterestRate to 5%
        setAnnualInterestRate(.05);
        
        //formatting output
        System.out.print("Monthly payments for loan1 of $5000.00 and loan2 $31000.00 for 3, 5 and 6 year loans at 5% interest.\n");
        System.out.printf("Loan\t3 years\t5 years\t6 years\nLoan1\t%.2f\t%.2f\t%.2f\nLoan2\t%.2f\t%.2f\t%.2f", 
                loan1.calculateMonthlyPayment(36), loan1.calculateMonthlyPayment(60), loan1.calculateMonthlyPayment(72),
                loan2.calculateMonthlyPayment(36), loan2.calculateMonthlyPayment(60), loan2.calculateMonthlyPayment(72));
    }
    
}
